// https://github.com/nvim-treesitter/nvim-treesitter/issues/2583
public class Testo {
  void foo() {
    new StringBuilder().append("a",
  }
}
